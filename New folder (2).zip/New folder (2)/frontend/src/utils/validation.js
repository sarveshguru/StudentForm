// export const validate = {
//     name: v =>
//       v.length < 3 ? 'At least 3 characters' :
//       /[^A-Za-z ]/.test(v) ? 'Alphabets only' : '',
//     email: v =>
//       !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? 'Invalid email' : '',
//     course: v =>
//       !v ? 'Required' : '',
//     address: v =>
//       !/^[A-Za-z0-9,\-\/ ]+$/.test(v) ? 'Invalid address' : '',
//     mobile: v =>
//       !/^[0-9]{10,15}$/.test(v) ? '10–15 digits' : '',
//     dob: v =>
//       !v ? 'Required' : '',
//   };

// ../../utils/validation.js

export const validate = {
  first_name: (value) => {
    if (!/^[A-Za-z\s]+$/.test(value)) {
      return "First name should only contain letters and spaces";
    }
    if (value.length < 2) {
      return "First name must be at least 2 characters";
    }
    return ""; // No error
  },
  last_name: (value) => {
    if (!/^[A-Za-z\s]+$/.test(value)) {
      return "Last name should only contain letters and spaces";
    }
    if (value.length < 2) {
      return "Last name must be at least 2 characters";
    }
    return ""; // No error
  },
  age: (value) => {
    const num = Number(value);
    if (isNaN(num) || num < 18 || !/^\d+$/.test(value)) {
      return "Age must be a number of at least 18";
    }
    return ""; // No error
  },
  marks: (value) => {
    if (!value) {
      return "Please select a mark";
    }
    return ""; // No error
  },
};

export const validateLogin = (data) => {
  const errors = {};
  if (!data.email) {
    errors.email = "Email is required";
  } else if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(data.email)) {
    errors.email = "Invalid email format";
  }
  if (!data.password) {
    errors.password = "Password is required";
  }
  return errors;
};

export const validateSignup = (data) => {
  const errors = {};
  if (!data.username) {
    errors.username = "Username is required";
  } else if (data.username.length < 3) {
    errors.username = "Username must be at least 3 characters";
  }
  if (!data.email) {
    errors.email = "Email is required";
  } else if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(data.email)) {
    errors.email = "Invalid email format";
  }
  if (!data.password) {
    errors.password = "Password is required";
  } else if (data.password.length < 6) {
    errors.password = "Password must be at least 6 characters";
  }
  return errors;
};
