import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom"; // Import Link
import api from "../../services/api";

const FormPage = () => {
  const [candidates, setCadidates] = useState([]);

  useEffect(() => {
    api.get("/").then((res) => setCadidates(res.data));
  }, []);

  const handleDelete = (id) => {
    api
      .delete(`/${id}`)
      .then(() => setCadidates((sc) => sc.filter((ca) => ca.id !== id)));
  };

  return (
    <div className="">
      <div>
        <Link to="/add-candidate" className="btn btn-primary ms-4">
          Add New
        </Link>
      </div>
      <div className="table-responsive-sm">
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">first_name</th>
              <th scope="col">last_name</th>
              <th scope="col">age</th>
              <th scope="col">marks</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {candidates.map((ca) => (
              <tr key={ca.id}>
                <td>{ca.first_name}</td>
                <td>{ca.last_name}</td>
                <td>{ca.age}</td>
                <td>{ca.marks}</td>
                <td>
                  <button
                    onClick={() => handleDelete(ca.id)}
                    className="btn btn-danger me-2" // Added some margin
                  >
                    Delete
                  </button>
                  <Link
                    to={`/edit-candidate/${ca.id}`}
                    className="btn btn-warning"
                  >
                    Edit
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FormPage;
