// import React, { useState, useEffect } from "react";
// import { useNavigate, useParams } from "react-router-dom";
// import api from "../../services/api";

// const AddCandidate = () => {
//   const [first_name, setFirst_name] = useState("");
//   const [last_name, setLast_name] = useState("");
//   const [age, setAge] = useState("");
//   const [marks, setMarks] = useState("");

//   const [isEditMode, setIsEditMode] = useState(false);
//   const { id } = useParams(); // Get the ID from the URL if in edit mode
//   const navigate = useNavigate();

//   useEffect(() => {
//     // Check if we have an ID in the URL, indicating edit mode
//     if (id) {
//       setIsEditMode(true);
//       fetchCandidateData(id);
//     } else {
//       setIsEditMode(false);
//       // Optionally reset the form fields for adding
//       setFirst_name("");
//       setLast_name("");
//       setAge("");
//       setMarks("");
//     }
//   }, [id]);

//   const fetchCandidateData = async (candidateId) => {
//     try {
//       const response = await api.get(`/${candidateId}`); // Assuming your get by ID endpoint is just '/:id'
//       const data = response.data;
//       setFirst_name(data.first_name || "");
//       setLast_name(data.last_name || "");
//       setAge(data.age || "");
//       setMarks(data.marks || ""); // Ensure default empty string for select
//     } catch (error) {
//       console.error("Error fetching candidate data:", error);
//       // Optionally handle the error, e.g., display a message to the user
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const candidateData = {
//       first_name,
//       last_name,
//       age,
//       marks,
//     };

//     try {
//       if (isEditMode && id) {
//         // Update existing candidate
//         await api.put(`/${id}`, candidateData); // Assuming your update endpoint is also '/:id'
//         navigate("/"); // Navigate back to the list page
//       } else {
//         // Add new candidate
//         await api.post("/", candidateData); // Assuming your add endpoint is '/'
//         navigate("/"); // Navigate back to the list page
//       }
//     } catch (error) {
//       console.error("Error adding/updating candidate:", error);
//       // Optionally handle the error, e.g., display a message to the user
//     }
//   };

//   return (
//     <div className="container">
//       <h2>{isEditMode ? "Edit Candidate" : "Add New Candidate"}</h2>
//       <div className="mb-3">
//         <form onSubmit={handleSubmit}>
//           <label htmlFor="first_name" className="form-label">
//             First Name
//           </label>
//           <input
//             type="text"
//             id="first_name"
//             value={first_name}
//             placeholder="First Name"
//             onChange={(e) => setFirst_name(e.target.value)}
//             className="form-control"
//             required
//           />

//           <label htmlFor="last_name" className="form-label">
//             Last Name
//           </label>
//           <input
//             type="text"
//             id="last_name"
//             value={last_name}
//             placeholder="Last Name"
//             onChange={(e) => setLast_name(e.target.value)}
//             className="form-control"
//             required
//           />

//           <label htmlFor="age" className="form-label">
//             Age
//           </label>
//           <input
//             type="number"
//             id="age"
//             value={age}
//             placeholder="Age"
//             onChange={(e) => setAge(e.target.value)}
//             className="form-control"
//             required
//           />

//           <label htmlFor="marks" class="form-label">
//             Marks
//           </label>
//           <select
//             class="form-select form-select-lg"
//             id="marks"
//             value={marks} // Bind the value for editing
//             onChange={(e) => setMarks(e.target.value)}
//           >
//             <option value="" selected>
//               Select one or more
//             </option>
//             <option value="10">10</option>
//             <option value="20">20</option>
//             <option value="30">30</option>
//             <option value="40">40</option>
//             <option value="50">50</option>
//           </select>

//           <div className="mt-3">
//             {!isEditMode && (
//               <button type="submit" className="btn btn-primary">
//                 Add Student
//               </button>
//             )}
//             {isEditMode && (
//               <button type="submit" className="btn btn-warning">
//                 Update Student
//               </button>
//             )}
//             <button
//               type="button"
//               onClick={() => navigate("/")}
//               className="btn btn-secondary ms-2"
//             >
//               Cancel
//             </button>
//           </div>
//         </form>
//       </div>

//     </div>
//   );
// };

// export default AddCandidate;

// //////////////////////////////////////////////////////////////////////////////////

import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../services/api";
import { validate } from "../../utils/validation"; // Import the validate object

const AddCandidate = () => {
  const [data, setData] = useState({
    first_name: "",
    last_name: "",
    age: "",
    marks: "",
  });
  const [errors, setErrors] = useState({});
  const [isEditMode, setIsEditMode] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      setIsEditMode(true);
      fetchCandidateData(id);
    } else {
      setIsEditMode(false);
      setData({ first_name: "", last_name: "", age: "", marks: "" });
      setErrors({});
    }
  }, [id]);

  const fetchCandidateData = async (candidateId) => {
    try {
      const response = await api.get(`/${candidateId}`);
      const data = response.data;
      setData({
        first_name: data.first_name || "",
        last_name: data.last_name || "",
        age: String(data.age || ""),
        marks: String(data.marks || ""),
      });
    } catch (error) {
      console.error("Error fetching candidate data:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prevData) => ({ ...prevData, [name]: value }));
    const errorMessage = validate[name](value);
    setErrors((prevErrors) => ({ ...prevErrors, [name]: errorMessage }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {
      first_name: validate.first_name(data.first_name),
      last_name: validate.last_name(data.last_name),
      age: validate.age(data.age),
      marks: validate.marks(data.marks),
    };
    setErrors(newErrors);

    if (Object.values(newErrors).some((error) => error !== "")) {
      return;
    }

    try {
      if (isEditMode && id) {
        await api.put(`/${id}`, data);
      } else {
        await api.post("/", data);
      }
      navigate("/");
    } catch (error) {
      console.error("Error adding/updating candidate:", error);
    }
  };

  return (
    <div className="container">
      <h2>{isEditMode ? "Edit Candidate" : "Add New Candidate"}</h2>
      <div className="mb-3">
        <form onSubmit={handleSubmit}>
          <label htmlFor="first_name" className="form-label">
            First Name
          </label>
          <input
            type="text"
            id="first_name"
            name="first_name"
            value={data.first_name}
            placeholder="First Name"
            onChange={handleChange}
            className={`form-control ${errors.first_name ? "is-invalid" : ""}`}
            required
          />
          {errors.first_name && (
            <div className="invalid-feedback">{errors.first_name}</div>
          )}

          <label htmlFor="last_name" className="form-label">
            Last Name
          </label>
          <input
            type="text"
            id="last_name"
            name="last_name"
            value={data.last_name}
            placeholder="Last Name"
            onChange={handleChange}
            className={`form-control ${errors.last_name ? "is-invalid" : ""}`}
            required
          />
          {errors.last_name && (
            <div className="invalid-feedback">{errors.last_name}</div>
          )}

          <label htmlFor="age" className="form-label">
            Age
          </label>
          <input
            type="number"
            id="age"
            name="age"
            value={data.age}
            placeholder="Age"
            onChange={handleChange}
            className={`form-control ${errors.age ? "is-invalid" : ""}`}
            required
          />
          {errors.age && <div className="invalid-feedback">{errors.age}</div>}

          <label htmlFor="marks" className="form-label">
            Marks
          </label>
          <select
            className={`form-select form-select-lg ${
              errors.marks ? "is-invalid" : ""
            }`}
            id="marks"
            name="marks"
            value={data.marks}
            onChange={handleChange}
          >
            <option value="">Select one or more</option>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
          </select>
          {errors.marks && (
            <div className="invalid-feedback">{errors.marks}</div>
          )}

          <div className="mt-3">
            {!isEditMode && (
              <button type="submit" className="btn btn-primary">
                Add Student
              </button>
            )}
            {isEditMode && (
              <button type="submit" className="btn btn-warning">
                Update Student
              </button>
            )}
            <button
              type="button"
              onClick={() => navigate("/")}
              className="btn btn-secondary ms-2"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCandidate;
