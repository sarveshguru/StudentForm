import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import authApi from "../../services/authApi";
import { validateLogin, validateSignup } from "../../utils/validation";

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [data, setData] = useState({
    email: "",
    password: "",
    username: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedData = { ...data, [name]: value };
    setData(updatedData);
    setErrors({});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};
    if (isLogin) {
      newErrors = validateLogin(data);
    } else {
      newErrors = validateSignup(data);
    }
    setErrors(newErrors);

    if (Object.values(newErrors).some((error) => error !== "")) {
      return;
    }

    try {
      let response;
      if (isLogin) {
        response = await authApi.post("/login", {
          email: data.email,
          password: data.password,
        });
      } else {
        response = await authApi.post("/signup", {
          username: data.username,
          email: data.email,
          password: data.password,
        });
      }

      const responseData = response.data;

      if (response.status === 200) {
        localStorage.setItem("token", responseData.token);
        localStorage.setItem("user", JSON.stringify(responseData.user));
        navigate("/");
      } else {
        setErrors({ form: responseData.message || "Authentication failed" });
      }
    } catch (error) {
      setErrors({ form: error.response?.data?.message || "An error occurred" });
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-6">
          <div className="bg-white p-4 rounded-xl shadow-lg">
            <h2 className="text-2xl font-bold mb-4 text-center">
              {isLogin ? "Login" : "Sign Up"}
            </h2>
            {errors.form && (
              <div className="alert alert-danger" role="alert">
                {errors.form}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-3">
              {!isLogin && (
                <>
                  <label htmlFor="username" className="form-label">
                    Username
                  </label>
                  <input
                    type="text"
                    id="username"
                    name="username"
                    value={data.username}
                    placeholder="Username"
                    onChange={handleChange}
                    className={`form-control ${
                      errors.username ? "is-invalid" : ""
                    }`}
                    required
                  />
                  {errors.username && (
                    <div className="invalid-feedback">{errors.username}</div>
                  )}
                </>
              )}
              <label htmlFor="email" className="form-label">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={data.email}
                placeholder="Email"
                onChange={handleChange}
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                required
              />
              {errors.email && (
                <div className="invalid-feedback">{errors.email}</div>
              )}

              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={data.password}
                placeholder="Password"
                onChange={handleChange}
                className={`form-control ${
                  errors.password ? "is-invalid" : ""
                }`}
                required
              />
              {errors.password && (
                <div className="invalid-feedback">{errors.password}</div>
              )}

              <button type="submit" className="btn btn-primary w-100 mt-4">
                {isLogin ? "Login" : "Sign Up"}
              </button>
            </form>

            <div className="mt-4 text-center">
              <Link
                className=""
                onClick={() => {
                  setIsLogin((prev) => !prev);
                  setData({ email: "", password: "", username: "" });
                  setErrors({});
                }}
              >
                {isLogin
                  ? "Create an account"
                  : "Already have an account? Login"}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
