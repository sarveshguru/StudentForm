import React from "react";
import { Routes, Route } from "react-router-dom";
import FormPage from "./components/formPage/FormPage";
import AddCandidate from "./components/formPage/AddCandidate";
import AuthPage from "./components/authPage/AuthPage";

const AllRoutes = () => {
  return (
    <Routes>
      <Route path="/FormPage" element={<FormPage />} />
      <Route path="/Add-Candidate" element={<AddCandidate />} />
      <Route path="/Edit-Candidate/:id" element={<AddCandidate />} />

      <Route path="/" element={<AuthPage />} />
    </Routes>
  );
};

export default AllRoutes;
