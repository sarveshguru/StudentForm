const { body } = require("express-validator");

const createCandidateValidation = [
    
    body("first_name")
    .notEmpty()
    .withMessage(" First Name is required")
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage("Name must contain only letters and spaces"),

    body("last_name")
    .notEmpty()
    .withMessage(" Last Name is required")
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage("Name must contain only letters and spaces"),

  body("age")
    .optional()
    .isInt({ min: 0, max: 150 })
    .withMessage("Age must be a valid number between 0 and 150"),

    body("marks")
    .notEmpty()
    .isInt({ min: 0, max: 100 })
    .withMessage("Marks must be a valid number between 0 and 100"),
];

const updateCandidateValidation = [

    body("first_name")
    .notEmpty()
    .withMessage(" First Name is required")
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage("Name must contain only letters and spaces"),

    body("last_name")
    .notEmpty()
    .withMessage(" Last Name is required")
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage("Name must contain only letters and spaces"),

  body("age")
    .optional()
    .isInt({ min: 0, max: 150 })
    .withMessage("Age must be a valid number between 0 and 150"),

    body("marks")
    .notEmpty()
    .isInt({ min: 0, max: 100 })
    .withMessage("Marks must be a valid number between 0 and 150"),
  
];

module.exports = {
  createCandidateValidation,
  updateCandidateValidation,
};
