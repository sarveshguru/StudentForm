const db = require("../config/db");

const candidateController = {
  getAllcandidate: async (req, res) => {
    try {
      const [candidate] = await db.promise().query("SELECT * FROM candidate");
      res.status(200).json(candidate);
    } catch (error) {
      console.error("Error fetching candidate:", error);
      res.status(500).json({ message: "Failed to fetch candidate" });
    }
  },

  createCandidate: async (req, res) => {
    const { first_name, last_name, age, marks } = req.body;

    // Optional: Add basic field presence validation
    if (!first_name || !last_name || !age || !marks) {
      return res.status(400).json({ message: "All fields are required" });
    }

    try {
      const [result] = await db
        .promise()
        .query(
          "INSERT INTO candidate(first_name, last_name, age, marks) VALUES (?, ?, ?, ?)",
          [first_name, last_name, age, marks],
        );

      res
        .status(201)
        .json({
          id: result.insertId,
          message: "Candidate created successfully",
        });
    } catch (error) {
      console.error("Error creating candidate:", error);
      res.status(500).json({ message: "Failed to create candidate" });
    }
  },

  getCandidateById: async (req, res) => {
    const { id } = req.params;

    try {
      const [rows] = await db
        .promise()
        .query("SELECT * FROM candidate WHERE id = ?", [id]);

      if (rows.length === 0) {
        return res.status(404).json({ message: "Candidate not found" });
      }

      res.status(200).json(rows[0]);
    } catch (error) {
      console.error("Error fetching candidate:", error);
      res.status(500).json({ message: "Failed to fetch candidate" });
    }
  },

  updateCandidate: async (req, res) => {
    const { id } = req.params;
    const { first_name, last_name, age, marks } = req.body;

    // Optional: Field validation
    if (!first_name || !last_name || !age || !marks) {
      return res
        .status(400)
        .json({ message: "All fields are required for update" });
    }

    try {
      const [result] = await db
        .promise()
        .query(
          "UPDATE candidate SET first_name = ?, last_name = ?, age = ?, marks = ? WHERE id = ?",
          [first_name, last_name, age, marks, id],
        );

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Candidate not found" });
      }

      res.status(200).json({ message: "Candidate updated successfully" });
    } catch (error) {
      console.error("Error updating candidate:", error);
      res.status(500).json({ message: "Failed to update candidate" });
    }
  },

  deleteCandidate: async (req, res) => {
    const { id } = req.params;

    try {
      const [result] = await db
        .promise()
        .query("DELETE FROM candidate WHERE id = ?", [id]);

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Candidate not found" });
      }

      res.status(200).json({ message: "Candidate deleted successfully" });
    } catch (error) {
      console.error("Error deleting candidate:", error);
      res.status(500).json({ message: "Failed to delete candidate" });
    }
  },
};

module.exports = candidateController;
