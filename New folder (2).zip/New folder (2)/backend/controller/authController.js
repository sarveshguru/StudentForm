const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const db = require("../config/db"); // Import your database connection
const JWT_SECRET = "4a509db054b8a3553ef2";

const authController = {
  signup: async (req, res) => {
    const { username, email, password } = req.body;

    try {
      // Check if user with the email already exists
      const [existingUsers] = await db
        .promise()
        .query("SELECT * FROM users WHERE email = ?", [email]);

      if (existingUsers.length > 0) {
        return res.status(400).json({ message: "Email is already taken" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      // Insert the new user into the database
      const [result] = await db
        .promise()
        .query(
          "INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
          [username, email, hashedPassword],
        );

      const newUser = {
        id: result.insertId,
        username,
        email,
      };
      const token = jwt.sign(newUser, JWT_SECRET, {
        expiresIn: "1h",
      });

      res
        .status(201)
        .json({ message: "User created successfully", user: newUser, token });
    } catch (error) {
      console.error("Error during signup:", error);
      res.status(500).json({ message: "Signup failed" });
    }
  },

  login: async (req, res) => {
    const { email, password } = req.body;

    try {
      const [users] = await db
        .promise()
        .query("SELECT * FROM users WHERE email = ?", [email]);

      if (users.length === 0) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const user = users[0];
      const isPasswordValid = await bcrypt.compare(password, user.password);

      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const { id, username, email: userEmail } = user; // Extract relevant user data
      const token = jwt.sign({ id, username, email: userEmail }, JWT_SECRET, {
        expiresIn: "1h",
      }); // Include user data in the token

      res.status(200).json({
        message: "Login successful",
        user: { id, username, email: userEmail },
        token,
      }); // Return user and token
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Login failed" });
    }
  },
};

module.exports = authController;
