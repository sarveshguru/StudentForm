```sql

create database textdb4;
use textdb4;

create table candidate(
id INT AUTO_INCREMENT PRIMARY KEY,
first_name varchar(50),
last_name varchar(50),
age int,
marks int
);

select * from candidate;

CREATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL UNIQUE,
password VARCHAR(255) NOT NULL
);

select * from users;




```
