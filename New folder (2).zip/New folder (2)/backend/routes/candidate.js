const express = require("express")
const router = express.Router()
const candidateController = require("../controller/candidatecontroller.js")

const {
    createCandidateValidation,
    updateCandidateValidation,

} = require("../utils/candidatevalidation.js")
const {validationResult} = require("express-validator")

const validate = (req , res, next) => {
    const error = validationResult(req)
    if(!error.isEmpty()) {
        return res.status(400).json({error: error.array() })
    }
    next()
}

router.get("/", candidateController.getAllcandidate)

router.post("/",createCandidateValidation, validate, candidateController.createCandidate)

router.get("/:id", candidateController.getCandidateById)

router.put("/:id",updateCandidateValidation, validate, candidateController.updateCandidate)

router.delete("/:id", candidateController.deleteCandidate)

module.exports = router;