const cors = require("cors");
const express = require("express");
const authRoutes = require("./routes/authRoutes");
const candidateRoutes = require("./routes/candidate");

const app = express();
app.use(express.json());
app.use(cors());

const PORT = 5000;

app.use("/auth", authRoutes);
app.use("/candidate", candidateRoutes);

app.get("/", (req, res) => {
  res.send("Hello!");
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
